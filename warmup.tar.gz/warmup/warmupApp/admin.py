from warmupApp.models import User
from django.contrib import admin

admin.site.register(User)
