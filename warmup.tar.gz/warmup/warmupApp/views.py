# Create your views here.
from django.http import HttpResponse
from django.template import Context, loader
from warmupApp.models import User
# import the logging library
from django.views.decorators.csrf import csrf_protect
import logging
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.views.decorators.csrf import csrf_exempt
import sys 
from os import curdir, sep
import os
from django.http import Http404
import json



SUCCESS               =   1  # : a success
ERR_BAD_CREDENTIALS   =  -1  # : (for login only) cannot find the user/password pair in the database
ERR_USER_EXISTS       =  -2  # : (for add only) trying to add a user that already exists
ERR_BAD_USERNAME      =  -3  # : (for add, or login) invalid user name (only empty string is invalid for now)
ERR_BAD_PASSWORD      =  -4
#Global Message Variable
InfoAcquireMESSAGE = "Please enter your credentials below"
AlreadyExistMESSAGE = "This user name already exists. Please try again"
CantBeEmptyMESSAGE = "The user name should not be empty, please try again"
InvalidCredenMESSAGE = "Invalid username and password combination. Please try again"
# Get an instance of a logger
log = logging.getLogger(__name__)
@csrf_exempt
def index(request): 
	if request.method == "POST":
		if request.path == "/users/login":	
			return login(request)
		elif request.path=="/users/add":
			return adduser(request)
		else:
			raise Http404
	elif request.method=="GET":
		if request.path not in ["/client.html","/client.css","/client.js"]:
			raise Http404
		else:
			mimeType="text/html"
			if request.path.endswith(".css"):
				mimeType = "text/css"
			elif request.path.endswith(".js"):
				mimeType = "text/javascript"
			return render_to_response('warmupApp'+request.path,{"message": InfoAcquireMESSAGE},mimetype=mimeType)
	
	

def userExist(username):
	try:
			dbresult = User.objects.get(userName = username)
			Exist = True
	except:
			Exist=False
			dbresult = ""
	return (Exist,dbresult)

def validateUsername(name):
	return name!="" and len(name)<=	128
def validatePassword(pwd):
	return len(pwd)<=128

@csrf_exempt
def adduser(request):
	inData = json.loads(request.body)
	#sys.stderr.write(str(inData))
	#inData = dict(request.POST)
	#sys.stderr.write(str(inData.keys()))
	#sys.stderr.write(str(type(inData)))
	if "user" in inData:
		if userExist(inData["user"])[0]:
			return HttpResponse(json.dumps({'errCode': ERR_USER_EXISTS}),content_type="application/json" )
		else:
			inUserName= inData["user"]
			inPwd = inData["password"]
			if not validateUsername(inUserName):
				return HttpResponse(json.dumps({'errCode': ERR_BAD_USERNAME}),content_type="application/json" )
        		if not validatePassword(inPwd):
				return HttpResponse(json.dumps({'errCode': ERR_BAD_PASSWORD}),content_type="application/json" )
			try:
				tobeAdd = User(userName=inUserName, password = inPwd,count=1)
				tobeAdd.save()
				return HttpResponse(json.dumps({'errCode': SUCCESS, 'count':1,'user':inUserName}),content_type="application/json" )
			except:
				raise Http404


@csrf_exempt
def login(request): 
	inData = json.loads(request.body)
	if "user" in inData:
		inUserName = inData["user"]
		inpassword = inData["password"]
		temp = userExist(inUserName)
		if temp[0] and temp[1].password == inpassword:
			#Auth succeed
			temp[1].count+=1
			tempCount = temp[1].count
			temp[1].save()
			return HttpResponse(json.dumps({'errCode': SUCCESS, 'user': inUserName, 'count': tempCount}),content_type="application/json" )
		else:
			return HttpResponse(json.dumps({'errCode': ERR_BAD_CREDENTIALS}),content_type="application/json" )


		
